extern void __fastcall__ format_bank();
